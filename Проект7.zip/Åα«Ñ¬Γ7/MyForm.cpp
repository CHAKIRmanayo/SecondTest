#include "MyForm.h"
using namespace System;
using namespace System::Windows::Forms;

void main()
{
	������7::MyForm form;
	System::Windows::Forms::Application::Run(%form);

}

